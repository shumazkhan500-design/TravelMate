const pages=["home","create","trips","itinerary","explore","budget","profile"];
let trips=JSON.parse(localStorage.getItem("travelmateTrips")||"[]");

function showPage(id){
  pages.forEach(p=>document.getElementById(p)?.classList.remove("active"));
  document.getElementById(id)?.classList.add("active");
  if(id==="trips") renderTrips();
  window.scrollTo({top:0,behavior:"smooth"});
}
function selectDestination(name){
  document.getElementById("destination").value=name;
  showPage("create");
}
function createTrip(e){
  e.preventDefault();
  const trip={
    destination:document.getElementById("destination").value,
    people:document.getElementById("people").value,
    start:document.getElementById("start").value,
    end:document.getElementById("end").value,
    budget:Number(document.getElementById("budgetInput").value)
  };
  trips.push(trip);
  localStorage.setItem("travelmateTrips",JSON.stringify(trips));
  document.getElementById("itinTitle").textContent=`${trip.destination} Itinerary`;
  document.getElementById("totalBudget").textContent=`₹${trip.budget.toLocaleString("en-IN")}`;
  document.getElementById("remainingText").textContent=`Remaining: ₹${Math.max(trip.budget-19000,0).toLocaleString("en-IN")}`;
  document.getElementById("spentText").textContent=`Spent: ₹${Math.min(trip.budget,19000).toLocaleString("en-IN")}`;
  document.getElementById("progressBar").style.width=`${Math.min(95, trip.budget ? 19000/trip.budget*100 : 0)}%`;
  alert("Trip created successfully!");
  showPage("trips");
}
function renderTrips(){
  const box=document.getElementById("tripList");
  if(!trips.length){
    box.innerHTML=`<div class="form-card"><h3>No trips yet</h3><p>Create your first trip to see it here.</p></div>`;
    return;
  }
  box.innerHTML=trips.map((t,i)=>`
    <div class="trip-item">
      <div><h3>✈️ ${t.destination}</h3><p>${t.start} → ${t.end} • ${t.people} traveler(s) • Budget ₹${t.budget.toLocaleString("en-IN")}</p></div>
      <button onclick="openTrip(${i})">View trip</button>
    </div>`).join("");
}
function openTrip(i){
  const t=trips[i];
  document.getElementById("itinTitle").textContent=`${t.destination} Itinerary`;
  document.getElementById("totalBudget").textContent=`₹${t.budget.toLocaleString("en-IN")}`;
  showPage("itinerary");
}
function filterPlaces(){
  const q=document.getElementById("search").value.toLowerCase();
  document.querySelectorAll(".place-row").forEach(row=>{
    row.style.display=row.innerText.toLowerCase().includes(q)?"grid":"none";
  });
}
renderTrips();
