# TravelMate – Smart Travel Planner

College prototype project for a Travel Planner App.

## Features
- Home dashboard
- Create a trip
- Saved trips using browser localStorage
- Itinerary prototype
- Explore places with search
- Budget tracker
- Responsive mobile-friendly design

## GitHub Pages
This is a static HTML/CSS/JavaScript site, so it can be published directly with GitHub Pages.
